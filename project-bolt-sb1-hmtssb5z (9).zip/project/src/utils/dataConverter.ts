import { ReligiousSite } from '../types';

// Function to convert TypeScript data to JSON format
export function convertToJSON(sites: ReligiousSite[]): string {
  return JSON.stringify(sites, null, 2);
}

// Function to convert JSON back to TypeScript format
export function convertFromJSON(jsonString: string): ReligiousSite[] {
  return JSON.parse(jsonString);
}

// Example usage for teammates
export function generateJSONTemplate(): string {
  const template = [
    {
      "id": "example-temple-id",
      "name": "Example Temple Name",
      "type": "Temple",
      "typeColor": "bg-orange-100 text-orange-800",
      "state": "Your State Name",
      "location": "City, District",
      "description": "Detailed description of the religious site...",
      "image": "https://images.pexels.com/photos/XXXXX/pexels-photo-XXXXX.jpeg",
      "timings": "6:00 AM to 8:00 PM - Every day",
      "prasad": "Traditional offerings, Sacred items",
      "amenities": [
        "Clean premises",
        "Parking facilities",
        "Drinking water",
        "Restrooms"
      ],
      "festivals": [
        "Festival 1",
        "Festival 2",
        "Festival 3"
      ],
      "contact": "+91 XXXXX XXXXX",
      "nearestTransport": {
        "airport": "Airport Name - distance",
        "railway": "Railway Station - distance",
        "bus": "Bus Station - distance"
      },
      "nearbyAttractions": [
        "Attraction 1",
        "Attraction 2",
        "Attraction 3"
      ],
      "nearbyHotels": [
        "Hotel 1",
        "Hotel 2",
        "Hotel 3"
      ],
      "nearbyRestaurants": [
        "Restaurant 1",
        "Restaurant 2",
        "Restaurant 3"
      ],
      "specialFeatures": [
        "Feature 1",
        "Feature 2",
        "Feature 3"
      ]
    }
  ];
  
  return JSON.stringify(template, null, 2);
}